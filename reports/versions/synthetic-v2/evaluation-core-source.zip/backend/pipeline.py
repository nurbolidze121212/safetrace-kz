import io
import re
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from PIL import Image, ImageOps

from . import storage
from .analysis import local_context, normalize_text, score, verify_claims
from .config import DATA, OCR_VERSION, QR_VERSION, RULE_VERSION
from .graph import build_graph
from .links import SyntheticTransport, extract_urls, identifiers, live_fetch, trace
from .ocr import recognize
from .providers import GeminiProvider, LocalProvider, ProviderUnavailable
from .qr import decode as decode_qr

EXECUTOR = ThreadPoolExecutor(max_workers=1, thread_name_prefix="safetrace")
CANCELS: dict[str, threading.Event] = {}
ACTIVE = set()
QUEUE_LOCK = threading.RLock()
STAGES = ["originals", "ocr", "features", "links", "graph", "priority"]


def new_case(payload):
    case_id = uuid.uuid4().hex
    doc = {
        "id": case_id,
        "title": payload.title,
        "mode": payload.mode,
        "created_at": storage.now(),
        "status": "pending",
        "stage": "originals",
        "progress": 0,
        "materials": [],
        "stages": {stage: "pending" for stage in STAGES},
        "evidence": [],
        "limitations": [],
        "history": [],
        "versions": {"rules": RULE_VERSION, "ocr": OCR_VERSION, "qr": QR_VERSION},
    }
    for m in payload.materials:
        mat = m.model_dump(mode="json")
        mat.update(id=uuid.uuid4().hex)
        mat["original_sha256"] = storage.digest(mat["text"])
        doc["materials"].append(mat)
    storage.save(doc)
    return doc


def add_materials(case_id, materials):
    with QUEUE_LOCK:
        if case_id in ACTIVE:
            raise ValueError("Дождитесь завершения или отмены текущего анализа.")
        doc = storage.get(case_id)
        if doc["mode"] == "replay":
            raise ValueError("Сохраненный повтор неизменяем; создайте новый анализ.")
        if len(ACTIVE) >= 8:
            raise ValueError("Очередь заполнена: максимум 8 задач.")
        if len(doc["materials"]) + len(materials) > 20:
            raise ValueError("Не более 20 материалов в случае.")
        for material in materials:
            mat = material.model_dump(mode="json")
            mat.update(id=uuid.uuid4().hex, original_sha256=storage.digest(mat["text"]))
            doc["materials"].append(mat)
        storage.save(doc)
        submit(case_id)


def submit(case_id):
    with QUEUE_LOCK:
        if case_id in ACTIVE:
            return
        if len(ACTIVE) >= 8:
            raise ValueError("Очередь заполнена: максимум 8 задач.")
        ACTIVE.add(case_id)
        CANCELS[case_id] = threading.Event()
        doc = storage.get(case_id)
        if doc.get("score") is not None:
            doc["history"].append(
                {
                    "at": doc.get("analyzed_at"),
                    "analysis_id": doc.get("analysis_id"),
                    "score": doc["score"],
                    "trace": doc.get("trace"),
                    "mode": doc["mode"],
                    "evidence": doc.get("evidence"),
                    "materials": [m for m in doc["materials"] if m.get("source_evidence_id")],
                    "versions": doc.get("versions"),
                }
            )
        doc.update(status="pending", progress=0, stages={s: "pending" for s in STAGES})
        storage.save(doc)
        EXECUTOR.submit(_run, case_id)


def cancel(case_id):
    if event := CANCELS.get(case_id):
        event.set()


def recover():
    for doc in storage.all_cases():
        if doc["status"] in ("pending", "running"):
            doc.update(status="partial", stage="interrupted")
            doc["limitations"].append("Приложение перезапущено: нажмите «Повторить анализ».")
            storage.save(doc)


def _run(case_id):
    doc = storage.get(case_id)
    event = CANCELS[case_id]
    try:
        analyze(doc, cancelled=event.is_set, checkpoint=storage.save)
    except Exception:
        doc.update(status="error")
        doc["limitations"].append("Ошибка обработки. Оригиналы сохранены; доступен повтор.")
        if doc.get("stage") in doc["stages"]:
            doc["stages"][doc["stage"]] = "error"
        storage.save(doc)
    finally:
        with QUEUE_LOCK:
            ACTIVE.discard(case_id)
            CANCELS.pop(case_id, None)


def analyze(
    doc, cancelled=lambda: False, checkpoint=lambda doc: None, variant="full", fetch=None, use_ocr_cache=True
):
    started = time.perf_counter()
    doc.update(
        evidence=[],
        limitations=[],
        identifiers=[],
        analyzed_at=storage.now(),
        status="running",
        trace={"observations": [], "relations": []},
        versions={"rules": RULE_VERSION, "ocr": OCR_VERSION, "qr": QR_VERSION},
    )
    doc["analysis_id"] = uuid.uuid4().hex[:12]
    doc.pop("score", None)
    if doc["mode"] in ("synthetic", "replay"):
        doc["limitations"].append("Синтетический стенд: материалы и страницы созданы для демонстрации.")
    doc["limitations"].append("Индекс не является вероятностью нарушения или юридическим заключением.")
    sources, urls, images, counter = {}, [], [], 0

    def evidence(quote, source_id, method, **extra):
        nonlocal counter
        counter += 1
        eid = f"{doc['id']}-{doc['analysis_id']}-e{counter}"
        doc["evidence"].append(
            {
                "id": eid,
                "quote": quote,
                "source_id": source_id,
                "method": method,
                "at": storage.now(),
                **extra,
            }
        )
        return eid

    def stage(name):
        if cancelled():
            doc["status"] = "cancelled"
            for key, value in doc["stages"].items():
                if value in ("pending", "running"):
                    doc["stages"][key] = "cancelled"
            checkpoint(doc)
            return False
        previous = doc.get("stage")
        if previous in doc["stages"] and doc["stages"][previous] == "running":
            doc["stages"][previous] = "completed"
        doc.update(stage=name, progress=round(STAGES.index(name) / len(STAGES) * 100))
        doc["stages"][name] = "running"
        checkpoint(doc)
        return True

    if not stage("originals"):
        return doc
    for mat in doc["materials"]:
        mat["source_evidence_id"] = evidence(
            mat["source"],
            mat["id"],
            "user_supplied",
            material_id=mat["id"],
            note="Источник заявлен при импорте; авторство не проверено.",
        )
        sources[mat["id"]] = mat["text"] + ("\n" + mat["url"] if mat["url"] else "")
        mat["normalized_text"] = normalize_text(mat["text"])
    if not stage("ocr"):
        return doc
    for mat in doc["materials"]:
        mat.pop("ocr", None)
        mat.pop("qr", None)
        if mat.get("image_id") and variant != "baseline":
            try:
                path = DATA / "originals" / mat["image_id"]
                mat["image_sha256"] = storage.digest(path.read_bytes())
                mat["ocr"] = recognize(path, use_cache=use_ocr_cache)
                source_id = mat["id"] + "-ocr"
                sources[source_id] = mat["ocr"]["text"]
                for line in mat["ocr"]["lines"]:
                    line["evidence_id"] = evidence(
                        line["text"],
                        source_id,
                        "ocr",
                        material_id=mat["id"],
                        polygon=line["polygon"],
                        confidence=line["confidence"],
                    )
                if not mat["ocr"]["lines"]:
                    doc["limitations"].append("OCR не нашел читаемый текст.")
                with Image.open(path) as im:
                    buffer = io.BytesIO()
                    clean = ImageOps.exif_transpose(im).convert("RGB")
                    clean.thumbnail((1600, 1600))
                    clean.save(buffer, format="PNG")
                    if len(images) < 2:
                        images.append(buffer.getvalue())
            except Exception:
                doc["limitations"].append(
                    "OCR недоступен для одного изображения; остальные материалы обработаны."
                )
                doc["stages"]["ocr"] = "partial"
            try:
                mat["qr"] = decode_qr(DATA / "originals" / mat["image_id"], use_cache=use_ocr_cache)
                for code in mat["qr"]["codes"]:
                    code["evidence_id"] = evidence(
                        code["text"],
                        mat["id"] + "-qr",
                        "qr_decode",
                        material_id=mat["id"],
                        polygon=code["polygon"],
                        note=code["reason"] or "Адрес декодирован из QR; безопасность проверяется отдельно.",
                    )
            except Exception:
                doc["limitations"].append("QR-коды одного изображения не удалось проверить.")
                doc["stages"]["ocr"] = "partial"
        if cancelled():
            stage("features")
            return doc
    if not stage("features"):
        return doc
    provider = GeminiProvider() if doc["mode"] == "cloud" else LocalProvider()
    method = "cloud_model" if doc["mode"] == "cloud" else "local_rule"
    try:
        context = provider.extract(sources, images)
    except ProviderUnavailable as exc:
        doc["limitations"].append(str(exc))
        context = LocalProvider().extract(sources)
        method = "local_rule"
        doc["stages"]["features"] = "partial"
    claims, rejected = verify_claims(context, sources)
    if method == "local_rule" and len(doc["materials"]) > 1:
        claims = []
        for mat in doc["materials"]:
            own_sources = {
                key: text for key, text in sources.items() if key in (mat["id"], mat["id"] + "-ocr")
            }
            verified, _ = verify_claims(local_context(own_sources), own_sources)
            claims.extend(verified)
    if method == "cloud_model" and (len(doc["materials"]) > 2 or sum(map(len, sources.values())) > 40000):
        doc["limitations"].append(
            "Облачный бюджет: не более двух изображений и 40 000 символов за вызов; большой пакет требует разделения."
        )
        doc["stages"]["features"] = "partial"
    for claim in claims:
        claim["evidence_id"] = evidence(
            claim["quote"],
            claim["source_id"],
            method,
            start=claim["start"],
            end=claim["end"],
            material_id=claim["source_id"].removesuffix("-ocr"),
        )
    doc.update(context=context.model_dump(), claims=claims, rejected_claims=rejected, provider=method)
    doc["limitations"].extend(context.limitations)
    if rejected:
        doc["limitations"].append(f"Отклонено цитат без совпадения с источником: {len(rejected)}.")
    for mat in doc["materials"]:
        mat["urls"] = []
        mat["promo_codes"] = []
        mat["content_evidence_ids"] = []
        for source_id in (mat["id"], mat["id"] + "-ocr"):
            if sources.get(source_id, "").strip():
                mat["content_evidence_ids"].append(
                    evidence(
                        sources[source_id],
                        source_id,
                        "ocr" if source_id.endswith("-ocr") else "source_text",
                        material_id=mat["id"],
                    )
                )
            for match in re.finditer(
                r"\b(?:промокод|код|promo\s*code)\s*[:=]?\s*([A-Za-zА-Яа-я0-9]{3,32})",
                sources.get(source_id, ""),
                re.I,
            ):
                code = match.group(1)
                eid = evidence(
                    match.group(),
                    source_id,
                    "source_text",
                    material_id=mat["id"],
                    note="Код из текста без подтвержденной области назначения.",
                )
                mat["promo_codes"].append({"value": code, "evidence_id": eid})
            for url in extract_urls(mat["text"] if source_id == mat["id"] else sources.get(source_id, "")):
                mat["urls"].append(url)
                evidence(
                    url,
                    source_id,
                    "ocr" if source_id.endswith("-ocr") else "source_text",
                    material_id=mat["id"],
                )
        if mat["url"]:
            mat["urls"].append(mat["url"])
            evidence(
                mat["url"],
                mat["id"],
                "source_text",
                material_id=mat["id"],
                note="Адрес из отдельного поля URL сохранен без обрезки параметров.",
            )
        for code in mat.get("qr", {}).get("codes", []):
            mat["content_evidence_ids"].append(code["evidence_id"])
            if code["valid_url"]:
                mat["urls"].append(code["text"])
        mat["urls"] = list(dict.fromkeys(mat["urls"]))
        urls.extend(mat["urls"])
    if not stage("links"):
        return doc
    if variant == "full":
        fetch = fetch or (SyntheticTransport() if doc["mode"] == "synthetic" else live_fetch)
        doc["trace"] = trace(list(dict.fromkeys(urls)), fetch, cancelled)
    page_claims = []
    for obs in doc["trace"]["observations"]:
        obs["evidence_id"] = evidence(
            obs.get("text") or obs.get("location") or obs.get("stop") or "",
            obs["url"],
            obs["method"],
            url=obs["url"],
            status_code=obs["status_code"],
            observation_id=obs["id"],
        )
        if obs["stop"]:
            doc["stages"]["links"] = "partial"
            doc["limitations"].append(f"Непроверенный участок: {obs['stop']}")
        if obs.get("budget_warning"):
            doc["limitations"].append(obs["budget_warning"])
            doc["stages"]["links"] = "partial"
        if obs["text"]:
            pc, _ = verify_claims(local_context({obs["url"]: obs["text"]}), {obs["url"]: obs["text"]})
            for claim in pc:
                claim["evidence_id"] = evidence(
                    claim["quote"],
                    obs["url"],
                    "local_rule",
                    start=claim["start"],
                    end=claim["end"],
                    url=obs["url"],
                )
            page_claims.extend(pc)
    by_obs = {o["id"]: o for o in doc["trace"]["observations"]}
    for rel in doc["trace"]["relations"]:
        obs = by_obs[rel["observation_id"]]
        rel["method"] = obs["method"]
        rel["evidence_id"] = evidence(
            rel["quote"],
            rel["from"] or rel["to"],
            rel["method"],
            url=rel["from"] or rel["to"],
            relation=rel["type"],
        )
    # Reachability from each original material keeps scoped identifiers attributable.
    for mat in doc["materials"]:
        reachable = set(mat["urls"])
        for _ in range(6):
            for rel in doc["trace"]["relations"]:
                if rel["from"] in reachable:
                    reachable.add(rel["to"])
        mat["reachable_urls"] = sorted(reachable)
        for obs in doc["trace"]["observations"]:
            has_outgoing = any(r["from"] == obs["url"] for r in doc["trace"]["relations"])
            if (
                obs["url"] in reachable
                and obs["status_code"]
                and 200 <= obs["status_code"] < 300
                and not has_outgoing
                and not obs.get("stop")
            ):
                for token in identifiers(obs["url"]):
                    entry = {**token, "material_id": mat["id"], "evidence_id": obs["evidence_id"]}
                    if entry not in doc["identifiers"]:
                        doc["identifiers"].append(entry)
    if not stage("graph"):
        return doc
    doc["graph"] = build_graph(doc)
    if not stage("priority"):
        return doc
    scopes = {}
    for token in doc["identifiers"]:
        scopes.setdefault(token["scope"], set()).add(token["material_id"])
    material_scores = []
    for mat in doc["materials"]:
        own_sources = {key: text for key, text in sources.items() if key in (mat["id"], mat["id"] + "-ocr")}
        own_claims = [c for c in claims if c["source_id"] in own_sources]
        own_pages = [c for c in page_claims if c["source_id"] in mat["reachable_urls"]]
        own_context = local_context(own_sources)
        repeated = any(mat["id"] in ids and len(ids) > 1 for ids in scopes.values())
        mat["score"] = score(own_claims, own_pages, own_context.context, repeated, own_context.contradictions)
        mat["context"] = own_context.model_dump()
        own_observations = [o for o in doc["trace"]["observations"] if o["url"] in mat["reachable_urls"]]
        any_page = any(o["text"] for o in own_observations)
        missing_route = bool(mat["urls"]) and not any_page
        strong_source_context = any(c["kind"] == "gambling" for c in own_claims) or own_context.context in (
            "warning",
            "news",
            "education",
            "free_game",
        )
        mat["sufficient_data"] = bool(any(t.strip() for t in own_sources.values())) and not (
            missing_route and not strong_source_context and variant == "full"
        )
        material_scores.append(mat["score"])
    doc["score"] = max(material_scores, key=lambda s: s["value"])
    doc["score"]["aggregation"] = (
        "Максимальный приоритет отдельного материала; признаки разных материалов не смешиваются."
    )
    if variant == "baseline":
        hit = bool(re.search(r"казино|casino|слот|ставк|фриспин|құмар", "\n".join(sources.values()), re.I))
        doc["score"].update(value=100 if hit else 0, level="high" if hit else "low")
    enough = all(m["sufficient_data"] for m in doc["materials"])
    if not enough:
        doc["limitations"].append(
            "Не хватает данных: отсутствие подтвержденного назначения не означает низкий риск."
        )
    doc["sufficient_data"] = enough
    doc["stages"]["priority"] = "completed"
    doc.update(
        status="partial"
        if any(s == "partial" for s in doc["stages"].values()) or not enough
        else "completed",
        progress=100,
        elapsed_ms=round((time.perf_counter() - started) * 1000, 1),
    )
    doc["limitations"] = list(dict.fromkeys(doc["limitations"]))
    checkpoint(doc)
    return doc
