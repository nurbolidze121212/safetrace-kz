from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .config import MAX_MATERIALS, MAX_TEXT

Mode = Literal["local", "cloud", "synthetic", "replay"]


class UserInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    @field_validator("*")
    @classmethod
    def valid_unicode(cls, value):
        if isinstance(value, str):
            try:
                value.encode("utf-8")
            except UnicodeError as exc:
                raise ValueError("Текст содержит некорректный Unicode.") from exc
        return value


class MaterialInput(UserInput):
    text: str = Field(default="", max_length=MAX_TEXT)
    url: str = Field(default="", max_length=2048)
    source: str = Field(default="Не указан", max_length=160)
    published_at: datetime | None = None
    image_id: str | None = Field(default=None, pattern=r"^[a-f0-9]{32}\.(png|jpg|webp)$")

    @field_validator("url")
    @classmethod
    def safe_url_shape(cls, value):
        if value:
            from .links import validate_url

            validate_url(value)
        return value

    @field_validator("published_at")
    @classmethod
    def timezone_required(cls, value):
        if value is not None and value.tzinfo is None:
            raise ValueError("Время публикации должно содержать часовой пояс.")
        return value

    @model_validator(mode="after")
    def nonempty(self):
        if not (self.text.strip() or self.url.strip() or self.image_id):
            raise ValueError("Добавьте текст, URL или изображение.")
        return self


class CaseInput(UserInput):
    title: str = Field(min_length=1, max_length=180)
    mode: Mode = "local"
    materials: list[MaterialInput] = Field(min_length=1, max_length=MAX_MATERIALS)


class DecisionInput(UserInput):
    decision: Literal["confirmed", "false_positive", "needs_data"]
    comment: str = Field(default="", max_length=2000)


class URLCorrectionInput(UserInput):
    material_id: str = Field(pattern=r"^[a-f0-9]{32}$")
    analysis_id: str = Field(min_length=1, max_length=64)
    original_url: str = Field(min_length=1, max_length=2048)
    corrected_url: str = Field(min_length=1, max_length=2048)
    comment: str = Field(min_length=3, max_length=1000)

    @field_validator("corrected_url")
    @classmethod
    def safe_corrected_url(cls, value):
        from .links import validate_url

        validate_url(value)
        return value

    @field_validator("comment")
    @classmethod
    def nonblank_comment(cls, value):
        if len(value.strip()) < 3:
            raise ValueError("Укажите, что проверено на оригинале.")
        return value


class Claim(BaseModel):
    kind: Literal[
        "call_to_action", "gambling", "bonus", "promise", "warning", "news", "education", "free_game"
    ]
    quote: str = Field(min_length=1, max_length=500)
    source_id: str = Field(max_length=2048)
    explanation: str = Field(max_length=800)
    start: int | None = Field(default=None, ge=0)
    end: int | None = Field(default=None, ge=0)


class ContextExtraction(BaseModel):
    model_config = ConfigDict(extra="forbid")
    language: Literal["ru", "kk", "mixed", "other"]
    context: Literal["promotion", "warning", "news", "education", "free_game", "affiliate", "ambiguous"]
    claims: list[Claim] = Field(max_length=30)
    contradictions: list[str] = Field(max_length=10)
    limitations: list[str] = Field(max_length=10)
